
/*
student version with NO assertion tests or refactoring implemented
*/
const max = 1000;   // Set upper bounds
const min = 0;      // Set lower bounds
let check4prime;    // global object

class Check4Prime {
    /*
    Calculates prime numbers and put true or false in an array
    */
    primeCheck(num) {
        // Initialize array to hold prime numbers
        let primeBucket = new Array(max + 1);

        // Initialize all elements to true, non-primes will be set to false later
        for (let i = 2; i <= max; i++) {
            primeBucket[i] = true;
        }

        // Do all multiples of 2 first
        let j = 2;
        for (let i = j + j; i <= max; i = i + j) { // start with 2j as 2 is prime
            primeBucket[i] = false; // set all multiples of 2 to false
        }

        for (j = 3; j <= max; j = j + 2) { // begin from 3 up to max
            if (primeBucket[j] == true) { // only do if primeBucket[j] is still a prime (not a multiple of 3, 5, 7, ...)
                for (let i = j + j; i <= max; i = i + j) { // start with 2j as j is a prime
                    primeBucket[i] = false; // set all multiples of the prime to false
                }
            }
        }

        // Check input against prime array
        if (primeBucket[num] == true) {
            return true;
        }
        else {
            return false;
        }
    }

    constructor() 
    {
        this.primeBucket = new Array(max + 1);
    }

    PreCalc()
    {
        let sqr = Math.sqrt(max);

        for (let i = 2; i <= max; i++) 
        {
            this.primeBucket[i] = true;
        }

        let j = 2;

        for (let i = j + j; i <= max; i = i + j) 
        { 
            this.primeBucket[i] = false; 
        }

        for (j = 3; j <= sqr; j = j + 2) 
        { 
            if (this.primeBucket[j] == true) 
            { 
                for (let i = j + j; i <= max; i = i + j) 
                { 
                    this.primeBucket[i] = false; 
                }
            }
        } 
    }


    /*
    Method to validate input
    */
    checkArgs() {

        // for (var i=0; i < arguments.length; i++)
        //     console.log(arguments[i]);

        // Check arguments for correct number of parameters if not throw new Error();
        if (arguments.length != 1) {
            throw new Error("arguments out of range")
        }
        else {
            // If undefined throw new Error();
            if (arguments[0] === undefined) {
                throw new Error("can´t be undifiend")
            }
            // If zero/empty throw new Error();
            else if (arguments[0] === "") {
                throw new Error("no input")
            }
            // Is not integer? throw new Error();
            else if (!Number.isInteger(arguments[0])) {
                throw new Error("no strings")
            }
            // Get integer from character
            let input = parseInt(arguments[0], 10);
            // If not a number throw new Error();
            if (isNaN(input)) {
                throw new Error("not a number")
            }
            // If less than lower bounds throw new Error();
            if (input < 0) {
                throw new Error("number is to low")
            }
            // If greater than upper bounds throw new Error();
            else if (input > max) {
                throw new Error("Number is to high")
            }
        }
    }
} // end Check4Prime class



/*
do the automated tests cases when developer performs test
*/
function checkTest() {
    // run various automated tests
    test_Check4Prime_known_true();
    test_Check4Prime_known_false();
    test_Check4Prime_checkArgs_neg_input();
    test_Check4Prime_checkArgs_above_upper_bound();
    test_Check4Prime_checkArgs_char_input();
    test_Check4Prime_checkArgs_2_inputs();
    test_Check4Prime_checkArgs_zero_input();
    test_Check4Prime_checkArgs_undefined_input();
    test_Check4Prime_checkArgs_non_integer_input();
}

/*
do the check for prime when ordinary user is running solution, you can merge this function with checkTest() if you want
*/
function check(num) {
    check4prime = new Check4Prime();
    //Did this so if you submit without any input the checkArgs for strings cant compare if the input is a string since it has no input.
    if (num == "") {
        num = 3;
    }
    checkTest(num);
    try {
        let description = `Number: ${num}. FAIL = Not prime, PASS = Prime`;
        check4prime.checkArgs(parseInt(num));
        //alert(`Is number${num} a prime? ${check4prime.primeCheck(num)}`)
        assert(check4prime.primeCheck(num), description);
    }
    catch (err) {
        console.log(err);
        let description = `Input/number: ${num}. Error in checkArgs()`;
        assert(check4prime.primeCheck(num), description);
    }
}


/*
append test result in list on web page 
*/
function assert(outcome, description) {
    let output = document.querySelector('#output');
    let li = document.createElement('li');
    li.className = outcome ? 'pass' : 'fail';
    li.appendChild(document.createTextNode(description));
    output.appendChild(li);
}

/*
Test methods, recommended naming convention
(Test)_MethodToTest_ScenarioWeTest_ExpectedBehaviour
In test method the pattern we use is "tripple A"
Arrange, Act and Assert
*/


// Test case 1, check known true primes
// Test case 1, check known true primes
function test_Check4Prime_known_true() {

    let description = `Test for false with: 5`;
    try {
        check4prime.checkArgs(5);
        assert(check4prime.primeCheck(5), description);
    } catch (error) {
        assert(!check4prime.primeCheck(5), description);
    }

}

// Test case 2, check known false primes
function test_Check4Prime_known_false() {
    let description = `Test for false with: 4`;
    try {
        check4prime.checkArgs(4);
        assert(!check4prime.primeCheck(4), description);
    } catch (error) {
        assert(check4prime.primeCheck(4), description);
    }
}

// Test case 3, check negative input
function test_Check4Prime_checkArgs_neg_input() {

    let description = `Test for negative input: -1`;
    try {
        check4prime.checkArgs(-1);
        assert(check4prime.primeCheck(-1), description);
    } catch (error) {
        assert(!check4prime.primeCheck(-1), description);
    }

}

// Test case 4, check for upper bound limit
function test_Check4Prime_checkArgs_above_upper_bound() {
    let description = `Test for upper bount limit: 10001`;
    try {
        check4prime.checkArgs(10001);
        assert(check4prime.primeCheck(10001), description);
    } catch (error) {
        assert(!check4prime.primeCheck(10001), description);
    }
}

// Test case 5, check for char input
function test_Check4Prime_checkArgs_char_input(char) {


    let description = `Test for char input: ${'a'}`;
    try {
        check4prime.checkArgs('a');
        assert(check4prime.primeCheck('a'), description);
    } catch (error) {
        assert(!check4prime.primeCheck('a'), description);
    }
}

// Test case 6, check for more than one input
function test_Check4Prime_checkArgs_2_inputs() {
    let arr = new Array(3, 20);
    let description = `Test for char input: ${arr[0]}, ${arr[1]}`;
    try {
        check4prime.checkArgs(arr[0], arr[1]);
        assert(check4prime.primeCheck(arr), description);
    } catch (error) {
        assert(!check4prime.primeCheck(arr), description);
    }

}

// Test case 7, check for zero/empty input
function test_Check4Prime_checkArgs_zero_input() {

    let description = `Test for zero/empty input: ${''}`;
    try {
        check4prime.checkArgs('');
        assert(check4prime.primeCheck(''), description);
    } catch (error) {
        assert(!check4prime.primeCheck(''), description);
    }

}

// Test case 8, check for undefined input
function test_Check4Prime_checkArgs_undefined_input() {
    let arr = new Array();
    let description = `Test for undefined input: ${arr[0]}`;
    try {
        check4prime.checkArgs(arr[0]);
        assert(check4prime.primeCheck(arr), description);
    } catch (error) {
        assert(!check4prime.primeCheck(arr), description);
    }
}

// Test case 9, check for non-integer input
function test_Check4Prime_checkArgs_non_integer_input() {
    let description = `Test for non-integer input: ${33.3}`;
    try {
        check4prime.checkArgs('33.3');
        assert(check4prime.primeCheck(33.3), description);
    } catch (error) {
        assert(!check4prime.primeCheck(33.3), description);
    }

}