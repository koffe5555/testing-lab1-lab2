# -*- coding: utf-8 -*-
'''
Unit test for leapyear.py
Student version
'''

import unittest
import leapyear


class KnownValues(unittest.TestCase):
    known_values = ((1904, "is a leap year"),
                    (1908, "is a leap year"),
                    (1912, "is a leap year"),
                    (1916, "is a leap year"),
                    (1920, "is a leap year"),
                    (1921, "isn't a leap year"),
                    (1924, "is a leap year"),
                    (1928, "is a leap year"),
                    (1932, "is a leap year"),
                    (1936, "is a leap year"),
                    (1940, "is a leap year"),
                    (1944, "is a leap year"),
                    (1948, "is a leap year"),
                    (1952, "is a leap year"),
                    (1956, "is a leap year"),
                    (1960, "is a leap year"),
                    (1964, "is a leap year"),
                    (1968, "is a leap year"),
                    (1972, "is a leap year"),
                    (1977, "isn't a leap year"),
                    (1976, "is a leap year"),
                    (1980, "is a leap year"),
                    (1984, "is a leap year"),
                    (1988, "is a leap year"),
                    (1992, "is a leap year"),
                    (1996, "is a leap year"),
                    (2000, "is a leap year"),
                    (2004, "is a leap year"),
                    (2008, "is a leap year"),
                    (2010, "isn't a leap year"),
                    (2012, "is a leap year"),
                    (2016, "is a leap year"),
                    (2020, "is a leap year"),
                    (2024, "is a leap year"))

    def test_known_values(self):
        '''to_roman should give known result with known input'''
        for integer, numeral in self.known_values:
            result = leapyear.to_leap_year(integer)
            self.assertEqual(numeral, result)
            print('subtracting {0} from input, adding {1} to output'.format(
                integer, numeral))

# Coverage score:
# Leapyear: 88%
# Leapyeartest: 96%
# Total: 92%


class AbcTest(unittest.TestCase):
    def test_string(self):
        '''to_leap_year should fail with string input'''
        self.assertRaises(leapyear.NotIntegerError, leapyear.to_leap_year, 'o')

    def test_too_large(self):
        '''to_leap_year should fail with large input'''
        self.assertRaises(leapyear.OutOfRangeError,
                          leapyear.to_leap_year, 2401)

    def test_blank(self):
        '''to_leap_year should fail with blank string'''
        self.assertRaises(leapyear.NotIntegerError, leapyear.to_leap_year, '')

    def test_negative(self):
        '''to_leap_year should fail with negative input'''
        self.assertRaises(leapyear.OutOfRangeError, leapyear.to_leap_year, -1)

    def test_non_integer(self):
        '''to_leap_year should fail with non-integer input'''
        self.assertRaises(leapyear.NotIntegerError, leapyear.to_leap_year, 0.5)


class XyzTest(unittest.TestCase):
    '''Your Xyz unittests code goes here'''


if __name__ == '__main__':
    unittest.main()
