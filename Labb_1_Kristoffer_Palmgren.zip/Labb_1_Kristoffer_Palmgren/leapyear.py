# -*- coding: utf-8 -*-
'''
There is a leap year every year whose number is perfectly divisible by four -
except for years which are both divisible by 100 and not divisible by 400.
The second part of the rule effects century years.
For example; the century years 1600 and 2000 are leap years,
but the century years 1700, 1800, and 1900 are not.
'''


class NotIntegerError(ValueError):
    pass


class OutOfRangeError(ValueError):
    pass


class InvalidNumeralError(ValueError):
    pass


def to_leap_year(year):
    '''Python program to check if the input year is a leap year or not'''
    if isinstance(year, str):
        raise NotIntegerError('Input can not be a string')
    if int(year) != year:
        raise NotIntegerError('Non-integers can not be converted')
    if not year:
        raise InvalidNumeralError('Input can not be blank')
    if not (0 < year < 2401):
        raise OutOfRangeError('number out of range (must be 1..2400)')
    return check_leap_year(year)
    # return year


def check_leap_year(year):
    if(year % 4 == 0 and year % 100 != 0 or year % 400 == 0):
        return "is a leap year"
    else:
        return "isn't a leap year"


if __name__ == '__main__':
    input_year = int(input("Enter year to be checked: "))
    print(to_leap_year(input_year))
