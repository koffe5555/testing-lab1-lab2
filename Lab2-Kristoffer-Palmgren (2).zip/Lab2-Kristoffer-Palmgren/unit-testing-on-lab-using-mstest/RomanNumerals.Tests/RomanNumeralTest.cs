using Microsoft.VisualStudio.TestTools.UnitTesting;
using RomanNumerals;
using System;
using System.Collections.Generic;

namespace RomanNumerals.Tests
{
    [TestClass]
    public class FromRomanBadInput
    {
        [DataTestMethod]
        [DataRow(null)]
        public void test_null(string input)
        {
            try
            {
                RomanNumeral Nunmeral = RomanNumeral.Parse(input);
            }
            catch (ArgumentNullException error)
            {
                StringAssert.Contains(error.Message, RomanNumeral.null_input);
            }
        }

        [DataTestMethod]
        [DataRow("")]
        public void test_blank(string input)
        {
            try
            {
                RomanNumeral Numeral = RomanNumeral.Parse(input);
            }
            catch (ArgumentNullException error)
            {
                StringAssert.Contains(error.Message, RomanNumeral.blank_input);
            }
        }

        [TestMethod]
        public void Test_repeated_pairs()
        {
            string[] repeated_array = { "CMCM", "CDCD", "XCXC", "XLXL", "IXIX", "IVIV" };
            try
            {
                foreach (string item in repeated_array)
                {
                    RomanNumeral Numeral = RomanNumeral.Parse(item);
                }
            }
            catch (ArgumentException error)
            {
                StringAssert.Contains(error.Message, "Error in Test_repeated_pairs();");
            }
        }

        [DataTestMethod]
        public void test_malformerd_antecedents()
        {
            string[] malformed_array = {"IIMXCC", "VX", "DCM", "CMM", "IXIV", "MCMC", "XCX", "IVI", "LM", "LD", "LC"};
            try
            {
                foreach (string item in malformed_array)
                {
                    RomanNumeral Numeral = RomanNumeral.Parse(item);
                }
            }
            catch (ArgumentException error)
            {
                StringAssert.Contains(error.Message, "Error in test_malformerd_antecedents();");
            }
        }

        [TestMethod]
        public void Test_too_many_repeated_numerals()
        {
            string[] many_repeated_array = { "MMMMM", "DD", "CCCC", "LL", "XXXX", "VV", "IIII" };
            try
            {
                foreach (string item in many_repeated_array)
                {
                    RomanNumeral Numeral = RomanNumeral.Parse(item);
                }
            }
            catch (ArgumentException error)
            {
                StringAssert.Contains(error.Message, "Error in Test_too_many_repeated_numerals");
            }
        }
    }
    [TestClass]
    public class RoundTripCheck
    {
        [TestMethod]
        public void Test_roundtrip()
        {
            for (int key = 1; key <= RomanNumeral.LIMIT; key++)
            {
                RomanNumeral romanNumeral = new RomanNumeral(key);
                RomanNumeral Numeral = RomanNumeral.Parse(romanNumeral.ToString());
                Assert.AreEqual(key, Numeral.Number);
            }
        }
    }
    [TestClass]
    public class TestKnownValues
    {

        [TestMethod]
        public void test_from_roman_known_values()
        {
            foreach (KeyValuePair<string, int> entry in RomanNumeral.VALUES)
            {
                RomanNumeral Numeral = RomanNumeral.Parse(entry.Key);
                Assert.AreEqual(entry.Value, Numeral.Number);
            }
        }
        [TestMethod]
        public void test_to_roman_knonw_valuse()
        {
            foreach (KeyValuePair<string, int> entry in RomanNumeral.VALUES)
            {
                RomanNumeral Numeral = new RomanNumeral(entry.Value);
                Assert.AreEqual(Numeral.ToString(), entry.Key);
            }
        }
    }

    [TestClass]
    public class ToRomanBadInput
    {
        [TestMethod]
        [DataRow(-1)]
        [DataRow(0)]
        [DataRow(5000)]
        public void ReturnArgumentOutOfRange(int input)
        {
            try
            {
                RomanNumeral Numeral = new RomanNumeral(input);
            }
            catch (ArgumentOutOfRangeException error)
            {
                StringAssert.Contains(error.Message, "Input out of range!");
            }
        }
        [TestMethod]
        [DataRow("badinput")]
        public void TestForBadInputsStrings(string input)
        {
            try
            {
                RomanNumeral Numeral = RomanNumeral.Parse(input);
                //var Num = new RomanNumeral(input);
            }
            catch (ArgumentException error)
            {
                StringAssert.Contains(error.Message, "Bad input string!");
            }
        }
        [TestMethod]
        [DataRow(null)]
        [DataRow("")]
        public void TestForNullAndEmptyInputStrings(string input)
        {
            Assert.ThrowsException<ArgumentException> (() => nullOrEmpty(input));
        }
        public void nullOrEmpty(string input)
        {
            if (string.IsNullOrEmpty(input))
            {
                throw new ArgumentException();
            }
        }
    }
}
