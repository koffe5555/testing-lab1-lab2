﻿namespace KeesTalksTech.Utilities.Latin.Numerals
{
    public enum RomanNumeralNotation
    {
        Substractive = 0,
        Additive = 1
    }
}
